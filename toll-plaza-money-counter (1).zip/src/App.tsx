import { useState, useEffect } from 'react';

interface TollRate {
  id: string;
  name: string;
  amount: number;
}

interface Transaction {
  id: string;
  vehicleType: string;
  amount: number;
  timestamp: Date;
}

interface Worker {
  username: string;
  name: string;
  role?: 'worker' | 'head';
}

export function App() {
  const [currentUser, setCurrentUser] = useState<Worker | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('toll_plaza_user');
    if (savedUser) {
      try {
        setCurrentUser(JSON.parse(savedUser));
      } catch (e) {
        localStorage.removeItem('toll_plaza_user');
      }
    }
  }, []);

  const handleLogin = (user: Worker) => {
    setCurrentUser(user);
    localStorage.setItem('toll_plaza_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('toll_plaza_user');
  };

  if (!currentUser) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  return <TollCounter currentUser={currentUser} onLogout={handleLogout} />;
}

function AuthScreen({ onLogin }: { onLogin: (worker: Worker) => void }) {
  type AuthMode = 'signup' | 'login' | 'head';
  const [mode, setMode] = useState<AuthMode>('signup');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (mode === 'signup') {
      if (!name || !username || !password) {
        setError('Please fill in all required fields.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match.');
        return;
      }
      onLogin({ username, name, role: 'worker' });
    } else if (mode === 'login') {
      if (!username || !password) {
        setError('Please enter both Worker ID and Password.');
        return;
      }
      onLogin({ username, name: username, role: 'worker' });
    } else if (mode === 'head') {
      if (!username || !password) {
        setError('Please enter Head Credentials.');
        return;
      }
      // Simulate validation for head login
      onLogin({ username, name: 'Plaza Head: ' + username, role: 'head' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden">
        <div className={`p-6 text-center transition-colors duration-300 ${mode === 'head' ? 'bg-amber-600' : 'bg-indigo-600'}`}>
          <h2 className="text-3xl font-bold text-white">Toll Plaza Security</h2>
          <p className="text-white opacity-80 mt-2">
            {mode === 'head' ? 'Administration Access Portal' : 'Worker Access Portal'}
          </p>
        </div>
        
        <div className="p-8">
          <div className="flex mb-6 bg-gray-100 rounded-lg p-1">
            <button
              className={`flex-1 py-2 rounded-md font-medium text-xs transition-colors ${mode === 'signup' ? 'bg-white text-indigo-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              onClick={() => { setMode('signup'); setError(''); }}
            >
              Sign Up
            </button>
            <button
              className={`flex-1 py-2 rounded-md font-medium text-xs transition-colors ${mode === 'login' ? 'bg-white text-indigo-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              onClick={() => { setMode('login'); setError(''); }}
            >
              Worker Login
            </button>
            <button
              className={`flex-1 py-2 rounded-md font-medium text-xs transition-colors ${mode === 'head' ? 'bg-white text-amber-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              onClick={() => { setMode('head'); setError(''); }}
            >
              Head Login
            </button>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 rounded-lg text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="John Doe"
                />
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {mode === 'head' ? 'Admin ID' : 'Worker ID / Username'}
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className={`w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 ${mode === 'head' ? 'focus:ring-amber-500' : 'focus:ring-indigo-500'}`}
                placeholder={mode === 'head' ? 'admin_01' : 'worker123'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={`w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 ${mode === 'head' ? 'focus:ring-amber-500' : 'focus:ring-indigo-500'}`}
                placeholder="••••••••"
              />
            </div>

            {mode === 'signup' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Confirm Password</label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="••••••••"
                />
              </div>
            )}

            <button
              type="submit"
              className={`w-full py-3 px-4 text-white font-medium rounded-lg transition-colors mt-6 ${mode === 'head' ? 'bg-amber-600 hover:bg-amber-700' : 'bg-indigo-600 hover:bg-indigo-700'}`}
            >
              {mode === 'signup' ? 'Register Worker' : mode === 'login' ? 'Worker Login' : 'Admin Login'}
            </button>
          </form>
          
          <div className="mt-6 text-center text-sm text-gray-500">
            <p>Authorized personnel only. All access is logged and monitored.</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function TollCounter({ currentUser, onLogout }: { currentUser: Worker; onLogout: () => void }) {
  // Predefined toll rates
  const tollRates: TollRate[] = [
    { id: 'car', name: 'Car/Jeep/Van', amount: 50 },
    { id: 'lcv', name: 'LCV (Mini Bus/Mini Truck)', amount: 80 },
    { id: 'bus', name: 'Bus/Truck', amount: 120 },
    { id: 'heavy', name: 'Heavy Vehicle', amount: 150 },
    { id: 'motorcycle', name: 'Motorcycle', amount: 20 },
  ];

  // State management
  const [selectedVehicle, setSelectedVehicle] = useState<string>('');
  const [customAmount, setCustomAmount] = useState<number>(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [totalCollection, setTotalCollection] = useState<number>(0);
  const [cashReceived, setCashReceived] = useState<number>(0);
  const [changeDue, setChangeDue] = useState<number>(0);

  // Calculate change when cash received changes
  useEffect(() => {
    if (selectedVehicle) {
      const rate = tollRates.find(r => r.id === selectedVehicle)?.amount || 0;
      setChangeDue(cashReceived - rate);
    } else if (customAmount > 0) {
      setChangeDue(cashReceived - customAmount);
    } else {
      setChangeDue(0);
    }
  }, [cashReceived, selectedVehicle, customAmount, tollRates]);

  // Handle vehicle selection
  const handleVehicleSelect = (vehicleId: string) => {
    setSelectedVehicle(vehicleId);
    setCustomAmount(0);
    setCashReceived(0);
  };

  // Handle custom amount input
  const handleCustomAmount = (amount: number) => {
    setCustomAmount(amount);
    setSelectedVehicle('');
    setCashReceived(0);
  };

  // Process payment
  const processPayment = () => {
    let amount = 0;
    
    if (selectedVehicle) {
      amount = tollRates.find(r => r.id === selectedVehicle)?.amount || 0;
    } else if (customAmount > 0) {
      amount = customAmount;
    }
    
    if (amount <= 0) return;
    
    if (cashReceived < amount) {
      alert('Insufficient cash received!');
      return;
    }
    
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      vehicleType: selectedVehicle 
        ? tollRates.find(r => r.id === selectedVehicle)?.name || 'Unknown'
        : 'Custom Amount',
      amount,
      timestamp: new Date()
    };
    
    setTransactions([newTransaction, ...transactions]);
    setTotalCollection(totalCollection + amount);
    
    // Reset form
    setSelectedVehicle('');
    setCustomAmount(0);
    setCashReceived(0);
    setChangeDue(0);
  };

  // Reset the counter
  const resetCounter = () => {
    if (window.confirm('Are you sure you want to reset the counter? This will clear all transactions.')) {
      setTransactions([]);
      setTotalCollection(0);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <header className="bg-white rounded-xl shadow-md p-6 mb-6 border-t-4 border-indigo-600">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div>
              <div className="flex items-center space-x-3">
                <h1 className="text-3xl font-bold text-gray-800">Toll Plaza Money Counter</h1>
                <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-medium border border-green-200">System Online</span>
                {currentUser.role === 'head' && (
                  <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full font-medium border border-amber-200">Admin Mode</span>
                )}
              </div>
              <p className="text-gray-600 mt-2 flex items-center">
                <span className="font-medium mr-1 text-indigo-700">
                  {currentUser.role === 'head' ? 'Administrator:' : 'Worker:'}
                </span> 
                {currentUser.name} (ID: {currentUser.username})
                <button onClick={onLogout} className="ml-4 text-sm text-red-500 hover:text-red-700 underline font-medium">Logout</button>
              </p>
            </div>
            <div className="mt-4 md:mt-0 text-right">
              <div className="text-2xl font-bold text-indigo-700">₹{totalCollection.toFixed(2)}</div>
              <div className="text-gray-600">Total Collection</div>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Vehicle Selection */}
          <div className="lg:col-span-2 space-y-6">
            {/* Vehicle Types */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Select Vehicle Type</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {tollRates.map((rate) => (
                  <button
                    key={rate.id}
                    onClick={() => handleVehicleSelect(rate.id)}
                    className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                      selectedVehicle === rate.id
                        ? 'border-indigo-500 bg-indigo-50 shadow-inner'
                        : 'border-gray-200 hover:border-indigo-300 hover:bg-indigo-50'
                    }`}
                  >
                    <div className="font-medium text-gray-800">{rate.name}</div>
                    <div className="text-indigo-600 font-bold mt-1">₹{rate.amount.toFixed(2)}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Custom Amount</h2>
              <div className="flex items-center space-x-4">
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={customAmount || ''}
                  onChange={(e) => handleCustomAmount(parseFloat(e.target.value) || 0)}
                  placeholder="Enter custom amount"
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                <button
                  onClick={() => handleCustomAmount(customAmount)}
                  className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  Set
                </button>
              </div>
            </div>

            {/* Payment Section */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Process Payment</h2>
              
              <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-600">Selected:</span>
                  <span className="font-medium">
                    {selectedVehicle 
                      ? tollRates.find(r => r.id === selectedVehicle)?.name 
                      : customAmount > 0 
                        ? `Custom Amount` 
                        : 'None'}
                  </span>
                </div>
                <div className="flex justify-between items-center text-lg font-bold">
                  <span>Total Amount:</span>
                  <span className="text-indigo-700">
                    ₹{(selectedVehicle 
                      ? tollRates.find(r => r.id === selectedVehicle)?.amount || 0 
                      : customAmount || 0).toFixed(2)}
                  </span>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 mb-2">Cash Received (₹)</label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={cashReceived || ''}
                    onChange={(e) => setCashReceived(parseFloat(e.target.value) || 0)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                    placeholder="Enter cash received"
                  />
                </div>
                
                <div className={`p-4 rounded-lg ${changeDue >= 0 ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
                  <div className="flex justify-between items-center">
                    <span className={changeDue >= 0 ? 'text-green-700' : 'text-red-700'}>
                      {changeDue >= 0 ? 'Change Due:' : 'Shortfall:'}
                    </span>
                    <span className={`font-bold ${changeDue >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                      ₹{Math.abs(changeDue).toFixed(2)}
                    </span>
                  </div>
                </div>
                
                <button
                  onClick={processPayment}
                  disabled={(!selectedVehicle && customAmount <= 0) || cashReceived <= 0}
                  className={`w-full py-3 px-4 rounded-lg font-medium transition-colors ${
                    (!selectedVehicle && customAmount <= 0) || cashReceived <= 0
                      ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                      : 'bg-indigo-600 text-white hover:bg-indigo-700'
                  }`}
                >
                  Process Payment
                </button>
              </div>
            </div>
          </div>

          {/* Right Column - Transactions */}
          <div className="space-y-6">
            {/* Recent Transactions */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-gray-800">Recent Transactions</h2>
                <button
                  onClick={resetCounter}
                  className="text-sm text-red-600 hover:text-red-800 font-medium"
                >
                  Reset Counter
                </button>
              </div>
              
              {transactions.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No transactions yet
                </div>
              ) : (
                <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
                  {transactions.map((transaction) => (
                    <div key={transaction.id} className="p-3 border border-gray-200 rounded-lg">
                      <div className="flex justify-between">
                        <div>
                          <div className="font-medium text-gray-800">{transaction.vehicleType}</div>
                          <div className="text-xs text-gray-500">
                            {transaction.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                        <div className="font-bold text-indigo-700">₹{transaction.amount.toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Summary */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Shift Summary</h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Total Transactions:</span>
                  <span className="font-medium">{transactions.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Average Transaction:</span>
                  <span className="font-medium">
                    {transactions.length > 0 
                      ? `₹${(totalCollection / transactions.length).toFixed(2)}` 
                      : '₹0.00'}
                  </span>
                </div>
                <div className="pt-3 border-t border-gray-200 flex justify-between text-lg font-bold">
                  <span>Total Collection:</span>
                  <span className="text-indigo-700">₹{totalCollection.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
